<?php
/*
Plugin Name: WooCommerce MedianetPay Payment Gateway
Plugin URI: https://www.medianetpay.ec/
Description: Plugin para integración de pagos con MedianetPay
Version: 2.0
Author: World Pos Solutions
Author URI: http://www.wposs.com/
*/
add_action('plugins_loaded', 'woocommerce_payment_gateway', 0);

function woocommerce_payment_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Payment_Plugin extends WC_Payment_Gateway
    {
        public function __construct()
        {
            /* ------------ Change data and logo for others clients -------------- */
            $this->method_title = 'MedianetPay';

            $this->url_develop = 'https://qa-api.medianetpay.ec/app/webservice/webcheckout/rest';
            $this->url_production = 'https://api.medianetpay.ec:4443/app/webservice/webcheckout/rest';
            /* ------------------------------------------------------------------- */

            $this->id = 'payment_gateway';
            $this->method_description = 'Integración de Woocommerce a la pasarela de pagos de ' . $this->method_title;
            $this->icon = apply_filters('woocommerce_payment_icon', plugins_url('/img/logo.jpg', __FILE__));
            $this->has_fields = false;

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->method_title;
            $this->user = $this->settings['user'];
            $this->key_Webservice = $this->settings['key_Webservice'];
            $this->gateway_url = $this->settings['gateway_url'];
            $this->iva = $this->settings['iva'];

            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array(&$this, 'process_admin_options'));
            }
            add_action('woocommerce_receipt_payment_gateway', array(&$this, 'receipt_page'));
        }

        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Habilitar/Deshabilitar', 'payment_gateway'),
                    'type' => 'checkbox',
                    'label' => __('Habilita la pasarela de pago ' . $this->method_title, 'payment_gateway'),
                    'default' => 'no'),
                'user' => array(
                    'title' => __('Usuario', 'payment_gateway'),
                    'type' => 'text',
                    'description' => __('Usuario ' . $this->method_title, 'payment_gateway')),
                'key_Webservice' => array(
                    'title' => __('Llave Webservice', 'payment_gateway'),
                    'type' => 'text',
                    'description' => __('Llave Webservice generada para su comercio.', 'payment_gateway')),
                'gateway_url' => array(
                    'title' => __('Ambiente', 'payment_gateway'),
                    'type' => 'select',
                    'options' => ['Desarrollo', 'Producción'],
                    'description' => __('Ambiente para la pasarela de pago ' . $this->method_title, 'payment_gateway')),
                'iva' => array(
                    'title' => __('Porcentaje Iva', 'payment_gateway'),
                    'type' => 'text',
                    'description' => __('Porcentaje de Iva para aplicar a las compras.', 'payment_gateway'),
                    'default' => '15',
                    'custom_attributes' => array(
                        'step' => 'any'
                    ),
                    'sanitize' => 'wc_format_decimal'),
            );

            add_filter('woocommerce_admin_settings_sanitize_option_iva', array($this, 'sanitize_iva_field'));
        }

        public function sanitize_iva_field($value)
        {
            if (!is_numeric($value)) {
                // Si no es numérico, establecer el valor como 0
                $value = 0;
            }
            return $value;
        }

        public function admin_options()
        {
            echo '<h3>' . __($this->method_title . ' Payment Gateway', 'payment_gateway') . '</h3>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        function receipt_page($order)
        {
            $form_generated = $this->generate_payment_form($order);
            if (strpos($form_generated, "http")) {
                echo '<p style="font-size: 18px"><b>' . __('Gracias por su pedido, para continuar el pago de click en la opción Pagar', 'payment_gateway') . '</b></p>';
                echo $form_generated;
            } else {
                echo '<p style="font-size: 18px"><b>' . __('Tenemos problemas para continuar el pago: ', 'payment_gateway') . '</b></p>';
                echo '<p style="font-size: 18px"><b>' . __($form_generated, 'payment_gateway') . '</b></p>';
            }
        }

        public function get_params_post($order_id)
        {
            $order = new WC_Order($order_id);
            $currency = get_woocommerce_currency();
            $amount = number_format(($order->get_total()), 2, '.', '');
            $shipping_total = number_format(($order->get_shipping_total()), 2, '.', '');
            $description = "";
            $products = $order->get_items();
            foreach ($products as $product) {
                $description .= $product['name'] . ' - ';
            }

            if (strlen($description) > 200) {
                $description = substr($description, 0, 185) . ' y otros...';
            }

            $reference = openssl_encrypt($order->id, 'AES-256-ECB', $this->get_api_key(), OPENSSL_RAW_DATA);
            $reference = base64_encode($reference);

            return array(
                'username' => $this->user,
                'key_webservice' => htmlspecialchars_decode($this->key_Webservice, ENT_NOQUOTES),
                'reference' => $reference,
                'currency' => $currency,
                'value' => $amount + $shipping_total,
                'iva' => $this->iva,
                'value_base_not_iva' => $shipping_total,
                'description' => 'Pedido de productos - ' . $description,
                'url_back' => plugins_url('/confirmation.php', __FILE__),
                'url_redirect' => plugins_url('/response.php?reference=' . $order->id, __FILE__),
            );
        }

        public function generate_payment_form($order_id)
        {
            $parameters_args = $this->get_params_post($order_id);
            $payload = json_encode($parameters_args);
            $url = (($this->gateway_url == '0') ? $this->url_develop : $this->url_production);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = json_decode(curl_exec($ch));

            if (!$result) {
                return 'Tenemos problemas de conexión, reintenta mas tarde...';
            } else {
                if ($result->message) {
                    return '<p style="font-size: 16px"><b>' . ucfirst($result->message) . '</b></p>';
                }
                if ($result->link) {
                    return '<a style="text-decoration: none;
                              padding: 16px 64px;
                              font-size: 18px;
                              color: white;
                              border: none;
                              border-radius: 6px;
                              cursor: pointer;
                              background: #003865;" href="' . $result->link . '">Pagar</a>';
                }
                return '<p style="font-size: 16px"><b>Problemas de consumo, reintenta mas tarde...</b></p>';
            }
            curl_close($ch);
        }

        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.19', '<=')) {
                return array('result' => 'success', 'redirect' => add_query_arg('order',
                    $order->id, add_query_arg('key', $order->order_key, get_permalink(get_option('woocommerce_pay_page_id'))))
                );
            } else {
                return array(
                    'result' => 'success',
                    'redirect' => $order->get_checkout_payment_url(true)
                );
            }
        }

        function get_api_key()
        {
            return $this->key_Webservice;
        }
    }

    function add_plugin($methods)
    {
        $methods[] = 'WC_Payment_Plugin';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_plugin');
}