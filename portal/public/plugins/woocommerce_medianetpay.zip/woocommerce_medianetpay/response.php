<?php
require_once '../../../wp-blog-header.php';
require_once './payment.php';
get_header('shop');

$reference = $_GET['reference'];
$order = new WC_Order($reference);

?>
    <style>
        .storefront-breadcrumb {
            display: none !important;
        }

        th, td {
            background-color: transparent !important;
        }

        .site-content {
            background-color: #F5F5F5;
        }

        .card-voucher {
            width: 100%;
            max-width: 600px;
            margin: 30px 0;
            background: #FFFFFF;
            box-shadow: -18px -18px 30px rgba(255, 255, 255, 0.25), 18px 18px 30px rgba(209, 217, 230, 0.25);
            border-radius: 10px;
            font-family: 'Roboto', sans-serif !important;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            grid-area: header;
            padding: 10px 0;
            margin: 0 30px;
            font-weight: bolder;
            color: #5a5a5a;
            height: 80px;
            border-bottom: 2px solid #c6c6c6;
            font-size: 18px;
        }

        .card-img {
            height: 40px;
        }

        .card-body {
            padding: 30px;
            color: #384461;
        }

        .card-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-row:last-child {
            margin-bottom: 0;
        }

        .bandage {
            padding: 10px 16px;
            border-radius: 4px;
            font-size: 14px;
        }

        .success {
            background-color: #E7F9F1;
            color: #03C10E;
        }

        .warning {
            background-color: #FFF8E3;
            color: #FFBF01;
        }

        .error {
            background-color: #FAEDED;
            color: #FF040E;
        }

        .card-footer {
            padding: 20px 30px;
            line-height: 1.2;
            background-color: #C6C6C6;
            border-radius: 0 0 10px 10px;
            font-size: 14px;
        }
    </style>
    <center>
        <div class="card-voucher">
            <?php if ($order->status != 'failed') { ?>
                <div class="card-header">
                    <span>Detalle de la transacción</span>
                    <img class="card-img" src="img/logo.jpg" alt="">
                </div>
                <div class="card-body">
                    <div class="card-row">
                        <span>Estado de la transacción:</span>
                        <span class="bandage <?= ($order->status == 'pending') ? 'warning' : 'success' ?>"><?= ($order->status == 'pending') ? 'Pago pendiente' : 'Pago exitoso' ?></span>
                    </div>
                    <div class="card-row">
                        <span>Fecha de la transacción:</span>
                        <span><?= date('Y-m-d') ?></span>
                    </div>
                    <div class="card-row">
                        <span>Valor total:</span>
                        <span>USD. <?= $order->total ?></span>
                    </div>
                    <div class="card-row">
                        <span>Nombres:</span>
                        <span><?= $order->billing_first_name ?></span>
                    </div>
                    <div class="card-row">
                        <span>Apellidos:</span>
                        <span><?= $order->billing_last_name ?></span>
                    </div>
                    <div class="card-row">
                        <span>Email:</span>
                        <span><?= $order->billing_email ?></span>
                    </div>
                </div>
                <div class="card-footer">
                    Su pago ha sido recibido con éxito, hemos enviado la confirmación de esta transacción a su E-mail.
                    Gracias por
                    utilizar nuestros servicios.
                </div>
            <?php } else { ?>
                <div class="card-header">
                    <span>¡Tenemos un problema!</span>
                    <img class="card-img" src="img/logo.jpg" alt="">
                </div>
                <div class="card-body" style="line-height: 1.2">
                    Lo sentimos, ha ocurrido un error mientras realizábamos el proceso de confirmación de pago con la
                    tienda,
                    Para mayor información ponte en contacto con el comercio.
                </div>
                <div class="card-footer">
                    No hemos podido completar esta operación exitosamente.
                    Gracias por
                    utilizar nuestros servicios.
                </div>
            <?php } ?>
        </div>
    </center>
    <script>
        document.title = "Confirmación de compra";
    </script>
<?php
get_footer('shop');