<?php
require_once '../../../wp-blog-header.php';
require_once './payment.php';


$postBody = file_get_contents("php://input");
$data = json_decode($postBody);

$reference = $data->reference;
$response = $data->response;

$api_key = (new WC_Payment_Plugin)->get_api_key();

$order = new WC_Order(openssl_decrypt(base64_decode($reference), 'AES-256-ECB', $api_key, OPENSSL_RAW_DATA));
global $woocommerce;

if ($response == "Rechazada" || $response == "Aprobada") {
        if ($response == "Aprobada") {
            $order->payment_complete();
            $woocommerce->cart->empty_cart();
        } else {
            $order->update_status('pending', __('Transaccion pendiente', 'woothemes'));
        }
} else {
    $order->update_status('failed', __('Transaccion fallida', 'woothemes'));
    $woocommerce->cart->empty_cart();
}
