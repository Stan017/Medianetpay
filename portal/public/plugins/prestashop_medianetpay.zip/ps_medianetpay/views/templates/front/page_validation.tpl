{* {extends "$layout"} *}

{block name="content"}

	<form id="medianetpay" method="post" action="{$url}" style="display:none;">
		<input name="usuario"    	 type="hidden" value="{$usuario}" ><br>
		<input name="llavemd5"     	 type="hidden" value="{$llavemd5}" ><br>
		<input name="referencia" 	 type="hidden" value="{$referencia}" ><br>
		<input name="moneda"      	 type="hidden" value="{$moneda}" ><br>
		<input name="valor"        	 type="hidden" value="{$valor}" ><br>
		<input name="iva"            type="hidden" value="{$iva}" ><br>
		<input name="baseiva" 	     type="hidden" value="{$baseiva}" ><br>
		<input name="descripcion"    type="hidden" value="{$descripcion}" ><br>
		<input name="nombres" 	     type="hidden" value="{$nombres}" ><br>
		<input name="apellidos" 	 type="hidden" value="{$apellidos}" ><br>
		<input name="email"    	     type="hidden" value="{$email}" ><br>
		<input name="urlback"    	 type="hidden" value="{$urlback}" ><br>
		<input name="urlredirect"    type="hidden" value="{$urlredirect}" ><br>
		<input name="version" 	     type="hidden" value="{$version}" ><br>
		<input name="Submit" type="submit"  type="hidden" value="Enviar" >
	</form>
	<script>
		document.getElementById("medianetpay").submit();
	</script>

	<p style="text-align: center; font-size: 20px; color:#a6c407; font-family: Arial; font-weight: 600; margin: 20px;">
		{* <img src="{$moduleDirUrl}" alt="MedianePay"> *}
		{l s="MedianetPay..." d='Modules.Ps_medianetpay.shop'}
	</p>
{/block}
