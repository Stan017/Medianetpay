<section id="medianetpay_hook_payment_option_detail">
	<p>
		{l s='Once you place your order you can pay using the payment method of your choice from MedinaetPay.' mod='ps_medianetpay'} <br>
	</p>
</section>
