{extends "$layout"}

{block name="content"}
	<section class="container">
		<div class="row">
			<div class="col">

				{if $valida}
				<h1 class="hed-tit">{l s="Your order has been received." mod='ps_medianetpay'}</h1>
				<br>
				<ul>
					<li><b>{l s="Thank you for your purchase!" mod='ps_medianetpay'}</b></li>
					<br>
					<li>{l s="You will receive an order confirmation email with details of your order and a link to track its progress." mod='ps_medianetpay'}</li>
				</ul>
				<p>
					<a href="{$urls.pages.my_account}" class="btn btn-primary">{l s="View your account" mod='ps_medianetpay'}</a>
				</p>
				{else}
				<h2 class="hed-tit">{l s="Error validating digital signature" mod='ps_medianetpay'}</h2>
					<p>
						<a href="{$urls.pages.contact}">{l s="Please contact us here" mod='ps_medianetpay'}</a>
						<br>
						{if $referencia}{l s="Order #" mod='ps_medianetpay'}{$referencia}{/if}
					</p>
					{/if}

			</div>
		</div>

	</section>
{/block}
