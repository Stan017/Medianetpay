$(document).ready(() => {
	
	// $(document).on("click", "#payment-confirmation button", function(event) { 
	// 	window.open(MedianetPayRegisterOrder);
	// });
})