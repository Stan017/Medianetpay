# MedinaetPay - Webcheckout - Prestashop 1.7

Módulo para pagos en línea por medio de Medianet en modo Webcheckout(se redirige a la pasarela de pagos de MedianetPay y una vez se 
procesa el pedido se retorna una respuesta al Prestashop), este módulo fue desarrollado para Bolivia.

## Traducciones

Las traducciones están el español Colombia (cb), las puedes cambiar al idioma que necesites ejemplo:

- `config_cb.xml.*` -> `config_es.xml`
- `translations/cb.php` -> `translations/es.php`

## Instalación
- Descargar el archivo `.zip` llamado `ps_medianetpay` dentro una carpeta de accesible.
- En el administrador de Prestashop ir a la sección de módulos y en `Subir un módulo` arrastrar el `.zip`.
- Entrar en las configuraciones del módulo e ingresar los datos solicitados.
- Ir a la configuración técnica de medianetpay e ingresar los datos:
	- URL redirect: https://midominio.com/module/ps_medianetpay/response
	- URL back: https://midominio.com/module/ps_medianetpay/confirmation

## Pruebas de compras
- En la configuración del módulo habilitar el modo Test en Si.
- Para probar los estados de pago se puede realizar una compra normal.
 