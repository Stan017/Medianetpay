<?php
class Ps_MedianetPayValidationModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'ps_medianetpay') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'validation'));
        }

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer))
            Tools::redirect('index.php?controller=order&step=1');

        $currency               = $this->context->currency;
        $moneda                 = $currency->iso_code;
        $value                  = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $order_state_approved   = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_APPROVED');
        $order_state_rejected   = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_REJECTED');
        $order_state_pending    = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_PENDING');

        // Active email data
        $mailVars       = array(
            // '{ps_medianetpay_owner}' => Configuration::get('PS_MEDIANETPAY_OWNER'),
            // '{ps_medianetpay_details}' => nl2br(Configuration::get('PS_MEDIANETPAY_DETAILS')),
            // '{ps_medianetpay_address}' => nl2br(Configuration::get('PS_MEDIANETPAY_ADDRESS'))
        );

        $this->module->validateOrder($cart->id, $order_state_pending, $value, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);

        $urlProduction  = 'https://qa-api.medianetpay.ec/app/webservice/webcheckout/rest';
        $urlSandbox     = 'https://qa-api.medianetpay.ec/app/webservice/webcheckout/rest';
        $order          = new Order($this->module->currentOrder); // $this->module->currentOrder is generate after validateOrder
        $referencia     = ($order->reference ? $order->reference : 0);
        $key_webservice       = Configuration::get('PS_MEDIANETPAY_LLAVEMD5');
        $username        = Configuration::get('PS_MEDIANETPAY_USER');
        $url            = (Configuration::get('PS_MEDIANETPAY_SAND_BOX') ?  $urlSandbox : $urlProduction);
        
        $result = '';
        for($i=0; $i<strlen( $referencia); $i++) {
            $char = substr( $referencia, $i, 1);
            $keychar = substr($key_webservice, ($i % strlen($key_webservice))-1, 1);
            $char = chr(ord($char)+ord($keychar));
            $result.=$char;
        }
        $referencia = base64_encode($result);

    

        $params = 	array(
            'username'		=>	$username,
            'key_webservice'		=>	$key_webservice,
            'reference'		=>	 $referencia,
            'currency'		=>	$moneda,
            'value'			=>	$value,
            'iva'		=>	'0',
            'value_base_iva'		=>	'0',
            'description'		=>	$this->module->description,
            'person_data' => array(
                'person_name'		=>	$customer->firstname,
                'person_lastname'      => $customer->lastname,
                'person_email'		=>	$customer->email
            ),
            'url_back'		=>	$this->context->link->getModuleLink( $this->module->name, 'confirmation'),
            'url_redirect'		=>	$this->context->link->getModuleLink( $this->module->name, 'response').'&referencia='.$referencia,
        );

        $payload = json_encode($params);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        $result = json_decode(curl_exec($ch));
    
        ?>
        <script type="text/javascript">
            window.location.href = "<?php echo $result->link?>";
        </script>
        <?php
        curl_close($ch);

    }
}
