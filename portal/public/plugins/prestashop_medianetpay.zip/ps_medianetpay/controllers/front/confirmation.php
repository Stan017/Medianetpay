<?php
class Ps_MedianetPayConfirmationModuleFrontController extends ModuleFrontController
{

    public function postProcess()
    {
        $approvedAnswer = 'Aprobada';
        $rejectedAnswer = 'Rechazada';

       $postBody = file_get_contents("php://input");
$data = json_decode($postBody);
$respuesta = $data->response;
$referencia = $data->reference;
    
        $estadoCompra 	= Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_PENDING');
        $llavemd5                 = Configuration::get('PS_MEDIANETPAY_LLAVEMD5');

        $result = '';
        $referencia = base64_decode($referencia);
        for($i=0; $i<strlen($referencia); $i++) {
            $char = substr($referencia, $i, 1);
            $keychar = substr($llavemd5, ($i % strlen($llavemd5))-1, 1);
            $char = chr(ord($char)-ord($keychar));
            $result.=$char;
        }
        $referencia= $result;

        if($respuesta == $approvedAnswer){

            $estadoCompra = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_APPROVED');

        }else if ($respuesta == $rejectedAnswer){

            $estadoCompra = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_REJECTED');

        }else{

            $estadoCompra = Configuration::get('PS_MEDIANETPAY_PAYMENT_STATUS_PENDING');

        }

        $sql = 'SELECT * FROM '._DB_PREFIX_.'orders  WHERE `reference` LIKE "'.$referencia.'"';
        $orderId = Db::getInstance()->getValue($sql);

        if($orderId != false){
            $history = new OrderHistory();
            $history->id_order = (int)$orderId;
            $history->changeIdOrderState( (int)$estadoCompra, (int)($orderId));
            // $history->add(true); // No send email
            $history->addWithemail(true); // Send email
        }
        $this->setTemplate('module:ps_medianetpay/views/templates/front/page_confirmation.tpl');

    }
}
