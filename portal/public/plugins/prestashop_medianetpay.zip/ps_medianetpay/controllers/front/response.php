<?php
class Ps_MedianetPayResponseModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'ps_medianetpay') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'response'));
        }
        $llavemd5                 = Configuration::get('PS_MEDIANETPAY_LLAVEMD5');
        $result = '';
        $referencia = base64_decode($_REQUEST['referencia']);
        for($i=0; $i<strlen($referencia); $i++) {
            $char = substr($referencia, $i, 1);
            $keychar = substr($llavemd5, ($i % strlen($llavemd5))-1, 1);
            $char = chr(ord($char)-ord($keychar));
            $result.=$char;
        }
        $referencia= $result;

        $this->context->smarty->assign([
            'valida'		=> 1,
            'referencia' => $referencia,
        ]);

        $this->setTemplate('module:ps_medianetpay/views/templates/front/page_response.tpl');

    }
}
