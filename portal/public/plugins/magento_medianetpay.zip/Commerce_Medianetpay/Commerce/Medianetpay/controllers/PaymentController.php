<?php
class Commerce_Medianetpay_PaymentController extends Mage_Core_Controller_Front_Action
{

    public function redirectAction()
    {
        $medianetpay = Mage::getModel('medianetpay/medianetpay');

        $payload = json_encode($medianetpay->getFormFields());
        $url =$medianetpay->getGatewayUrl();
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        $result = json_decode(curl_exec($ch));
		
		if(curl_exec($ch) === false)
{
    echo 'Curl error: ' . curl_error($ch);
}
        ?>
<script type="text/javascript">
    window.location.href = "<?php echo $result->link?>";
</script>
<?php
        curl_close($ch);

    }

    public function responseAction()
    {

        $secure_key = Mage::getStoreConfig('payment/medianetpay/secure_key');
        $postBody = file_get_contents("php://input");
        $data = json_decode($postBody);

        $reference = $data->reference;
        $amount = $data->amount;
        $response = $data->response;

        $split = explode('.', $amount);
        $decimals = $split[1];
        if ($decimals % 10 == 0) {
            $amount = number_format($amount, 1, '.', '');
        }

        $return_message = $_POST['response_message_pol'];

        $result = '';
        $reference = base64_decode($reference);
        for($i=0; $i<strlen($reference); $i++) {
            $char = substr($reference, $i, 1);
            $keychar = substr($secure_key, ($i % strlen($secure_key))-1, 1);
            $char = chr(ord($char)-ord($keychar));
            $result.=$char;
        }
        $reference= $result;


        if ($response == 'Aprobada' || $response == 'Rechazada') {

            $order = Mage::getModel('sales/order')->loadByIncrementId($reference);
            $order->getPayment()->setTransactionId($reference);
            $order_comment = $return_message;

            foreach ($_POST as $key => $value) {
                $order_comment .= "<br/>$key: $value";
            }

            if ($response == 'Aprobada') {
                $order->getPayment()->registerCaptureNotification($_POST['valor']);
                $order->addStatusToHistory($order->getStatus(), $order_comment);
                $order->addStatusToHistory('complete', $order_comment);
            } elseif ($response == 'Rechazada') {
                $order->addStatusToHistory('canceled', $order_comment);
            }

            $order->save();


        } else {
            $order = Mage::getModel('sales/order')->loadByIncrementId($reference);
            $order->cancel();
            $order->addStatusToHistory($order->getStatus(), $return_message);
            $order->save();

        }
    }

    public function confirmationAction()
    {
        $checkout = Mage::getSingleton('checkout/session');
        $orderIncrementId = $checkout->getLastRealOrderId();

        if($orderIncrementId){
            $this->_redirect('checkout/onepage/success');
        } else {
            $this->_redirect('checkout/onepage/failure');
        }

    }

}