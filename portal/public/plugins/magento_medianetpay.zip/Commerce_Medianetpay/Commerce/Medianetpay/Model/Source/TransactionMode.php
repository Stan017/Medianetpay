<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * @category   Commerce
 * @package    Commerce_Medianetpay
 * @copyright  Copyright (c) 2013 gfranco.info [modified from vnphpexpert.com]
 */

class Commerce_Medianetpay_Model_Source_TransactionMode
{
    public function toOptionArray()
    {
        $options =  array();       ;
        $options[] = array(
            	   'value' => 'test',
            	   'label' => 'Test'
         );
		 $options[] = array(
            	   'value' => 'live',
            	   'label' => 'Live'
         );

        return $options;
    }
}