<?php

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Commerce
 * @package    Commerce_MedianetPay
 * @copyright  Copyright (c) 2013 gfranco.info [modified from vnphpexpert.com]
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Commerce_Medianetpay_Model_Medianetpay extends Mage_Payment_Model_Method_Abstract
{
    /**
     * unique internal payment method identifier
     *
     * @var string [a-z0-9_]
     */
    protected $_code = 'medianetpay';
    protected $_canUseForMultishipping  = false;

    protected $_formBlockType = 'medianetpay/form';
    protected $_infoBlockType = 'medianetpay/info';

    /**
     * Return Order place direct url
     *
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('medianetpay/payment/redirect', array('_secure' => true));
    }

    public function getGatewayUrl()
    {
        return Mage::getStoreConfig( 'payment/medianetpay/gateway_url' );
    }

    public function getFormFields()
    {
        $merchant_id = Mage::getStoreConfig( 'payment/medianetpay/merchant_id' );
        $secure_key = Mage::getStoreConfig( 'payment/medianetpay/secure_key' );
        $account_id = Mage::getStoreConfig( 'payment/medianetpay/account_id' );
        $gateway_url = Mage::getStoreConfig( 'payment/medianetpay/gateway_url' );
        $transaction_mode = Mage::getStoreConfig( 'payment/medianetpay/transaction_mode' );

        $checkout = Mage::getSingleton('checkout/session');
        $orderIncrementId = $checkout->getLastRealOrderId();
        $order = Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);

        $currency   = $order->getOrderCurrencyCode();

        $BAddress = $order->getBillingAddress();

        $paymentAmount = number_format($order->getGrandTotal(),2,'.','');
        $tax = number_format($order->getTaxAmount(),2,'.','');

        $taxReturnBase = number_format(($paymentAmount - $tax),2,'.','');
        if($tax == 0) $taxReturnBase = 0;
        //$taxReturnBase = $tax = 0;

        $ProductName = '';
        $items = $order->getAllItems();
        if ($items)
        {
            foreach($items as $item)
            {
                if ($item->getParentItem()) continue;
                $ProductName .= $item->getName() . '; ';
            }
        }
        $ProductName = rtrim($ProductName, '; ');

        if (strlen($ProductName) > 255){
            $ProductName = substr($ProductName,0,240).' y otros...';
        }

        $test = 0;
        if($transaction_mode == 'test') $test = 1;

        $extra1 = 'Magento Plugin';


        $result = '';
        for($i=0; $i<strlen($orderIncrementId); $i++) {
            $char = substr($orderIncrementId, $i, 1);
            $keychar = substr($secure_key, ($i % strlen($secure_key))-1, 1);
            $char = chr(ord($char)+ord($keychar));
            $result.=$char;
        }
        $signature = base64_encode($result);

        $params = 	array(
            'username'		=>	$merchant_id,
            'key_webservice'		=>	$secure_key,
            'reference'		=>	$signature,
            'currency'		=>	$currency,
            'value'			=>	$paymentAmount,
            'iva'		=>	$tax,
            'value_base_iva'		=>	$taxReturnBase,
            'description'		=>	$ProductName,
            'person_data' => array(
                'person_name'		=>	$order->getShippingAddress()->getFirstname(),
                'person_lastname'      => $order->getShippingAddress()->getLastname(),
                'person_email'		=>	$order->getCustomerEmail(),
                'person_direction'		=>	$order->getShippingAddress()->getStreet1().' '.$order->getShippingAddress()->getStreet2(),
                'person_phone'		=>	$order->getShippingAddress()->getTelephone(),
            ),
            'url_back'		=>	Mage::getUrl('medianetpay/payment/response'),
            'url_redirect'		=>	Mage::getUrl('medianetpay/payment/confirmation'),
        );
        return $params;
    }

    /**
     * Return true if the method can be used at this time
     *
     * @return bool
     */
    public function isAvailable($quote=null)
    {
        return true;
    }
}
